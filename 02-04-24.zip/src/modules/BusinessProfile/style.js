import { Card } from "antd";
import styled from "styled-components";

export const StyledBusinessProfile = styled.div`



`

export const BusinessCard = styled(Card)`

`
export const StyledSignature = styled.div`

transition: transform 0.5s ease; 

&:hover{
     transform: rotate(3deg);
 }
 
`
