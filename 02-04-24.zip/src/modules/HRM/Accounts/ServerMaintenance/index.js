import React from 'react'
import ViewServerMaintainTable from './ViewServermaintain/Partials/ViewServerMaintainTable'

const ViewServerMaintenance = () => {
  return (
    <div>
        <ViewServerMaintainTable/>
    </div>
  )
}

export default ViewServerMaintenance