import React from 'react'
import ViewQuotationTable from './Partials/ViewQuotationTable'

const Quotation = () => {
    return (
        <div>
            <ViewQuotationTable />
        </div>
    )
}

export default Quotation