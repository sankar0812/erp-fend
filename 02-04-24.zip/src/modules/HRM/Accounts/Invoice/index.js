import React from 'react'
import { ViewInvoice } from './Partials/ViewInvoice'

const Invoice = () => {
  return (
    <div>
      <ViewInvoice />
    </div>
  )
}

export default Invoice