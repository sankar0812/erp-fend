import React from 'react'
import ViewTraining from './Partials/TrainingTable'

export const Training = () => {
  return (
    <ViewTraining/>
  )
}
