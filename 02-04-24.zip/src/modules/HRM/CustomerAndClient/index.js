import React from 'react'
import {CustomerAndClientForm} from './Partials/CustomerAndClientForm'

export const CustomerAndClient = () => {
    return (
        <div><CustomerAndClientForm /></div>
    )
}
