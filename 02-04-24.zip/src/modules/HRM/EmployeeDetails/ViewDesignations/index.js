import React from 'react'
import ViewDesignations from './Partials/ViewDesignations'

export const Designation = () => {
  return (
    <div>
        <ViewDesignations/>
    </div>
  )
}
