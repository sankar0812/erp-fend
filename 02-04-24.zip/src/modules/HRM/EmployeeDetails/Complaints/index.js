import React from 'react'
import { AdminViewComplaints } from './Partials/AdminViewComplaints'

export const ComplaintsView = () => {
  return (
    <AdminViewComplaints/>
  )
}
