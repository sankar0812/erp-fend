import React from 'react'
import { ViewEmployeeTable } from './Partials/ViewEmployeeTable'

export const ViewEmploye = () => {
  return (
      <ViewEmployeeTable/>
  )
}
