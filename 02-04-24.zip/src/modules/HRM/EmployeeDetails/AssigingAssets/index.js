import React from 'react'
import { AssigningAssetsTable } from './Partials/AssigningAssetsTable'

export const AssigningAssets = () => {
  return (
    <AssigningAssetsTable/>
  )
}
