export const Approval = [
    {
      label: "Selected",
      value: "selected",
    },
    {
      label: "Rejected",
      value: "rejected",
    }
  ];