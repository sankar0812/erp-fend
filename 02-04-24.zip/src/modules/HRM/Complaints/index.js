import React from 'react'
import { ViewComplaints } from './Partials/ViewComplaints'

export const EmployeeComplaints = () => {
  return (
    <ViewComplaints/>
  )
}
