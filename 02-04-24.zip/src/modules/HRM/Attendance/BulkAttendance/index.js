import React, { Fragment } from 'react'
import {AttendanceContainer} from './partials/AttendanceContainer'


export const BulkAttendance = () => {
  return (
    <Fragment>
      <AttendanceContainer/>
    </Fragment>
  )
}
