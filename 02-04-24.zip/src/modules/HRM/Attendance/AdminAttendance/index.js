import React from 'react'
import { ViewtableAttendance } from './Partials/ViewtableAttendance'

const EmpAttendanceView = () => {
  return (
    <div><ViewtableAttendance/></div>
  )
}

export default EmpAttendanceView