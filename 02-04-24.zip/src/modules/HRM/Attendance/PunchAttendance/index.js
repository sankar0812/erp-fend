import React, { Fragment } from 'react'
import { EmployeeAttendance } from './EmployeeAttendance'

export const Attendance = () => {
  return (
    <Fragment>
      <EmployeeAttendance />
    </Fragment>
  )
}
