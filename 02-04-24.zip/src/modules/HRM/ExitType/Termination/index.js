import React from 'react'
import EmployeeTermination from './Partials/EmployeeTermination'

export const EmpTermination = () => {
  return (
    <div><EmployeeTermination/></div>
  )
}
