import React from 'react'

const EmployeeTerminationTable = () => {
  return (
    <div>EmployeeTerminationTable</div>
  )
}

export default EmployeeTerminationTable