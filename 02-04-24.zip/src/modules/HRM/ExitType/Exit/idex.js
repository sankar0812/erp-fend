import React from 'react'
import EmployeeExit from './Partials/EmployeeExit'
import EmployeeExitTable from './Partials/EmployeeExitTable'

export const EmpExit = () => {
    return (
        <div><EmployeeExitTable /></div>
    )
}

