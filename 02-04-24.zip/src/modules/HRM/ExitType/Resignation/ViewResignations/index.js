import React from 'react'
import EmployeeResignationTable from './EmployeeResignationTable'

const ViewResignations = () => {
  return (
    <div>
        <EmployeeResignationTable/>
    </div>
  )
}

export default ViewResignations