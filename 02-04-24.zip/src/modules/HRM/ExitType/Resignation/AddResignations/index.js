import React from 'react'
import EmployeeResignation from './Partials/EmployeeResignation'

export const EmpResignation = () => {
  return (
    <div><EmployeeResignation /></div>
  )
}

