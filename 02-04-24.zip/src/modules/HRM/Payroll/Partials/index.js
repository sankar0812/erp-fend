import React from 'react'
import PayrollTable from './PayrollTable'

const Payroll = () => {
    return (
        <div><PayrollTable /></div>
    )
}

export default Payroll