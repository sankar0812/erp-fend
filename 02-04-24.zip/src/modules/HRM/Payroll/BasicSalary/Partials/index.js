import React from 'react'
import BasicSalaryTable from './BasicSalaryTable'

const index = () => {
  return (
    <div><BasicSalaryTable/></div>
  )
}

export default index