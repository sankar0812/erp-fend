import React from 'react'

export const SampleSmallForm = () => {
  return (
    <div>SampleSmallForm</div>
  )
}
