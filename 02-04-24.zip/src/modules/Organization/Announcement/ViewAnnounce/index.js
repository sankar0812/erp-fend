import React from 'react'
import { AnnouncementTable } from './Partials/ViewAnnounceTable'

const ViewAnnounce = () => {
  return (
    <div>
        <AnnouncementTable/>
        </div>
  )
}

export default ViewAnnounce