import React from 'react'
import { ChatBox } from './Parrtials/ChatBox'
import { Demo } from './Parrtials/Demo'

export const AIChat = () => {
  return (
    <ChatBox/>
    // <Demo/>
  )
}
