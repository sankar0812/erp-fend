import React from 'react'
import { PMDashView } from './Partials/PMDashView'

export const PMDashboard = () => {
  return (
    <PMDashView/>
  )
}
