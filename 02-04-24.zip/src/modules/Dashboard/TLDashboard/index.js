import React from 'react'
import { ViewTLDashboard } from './Partials/ViewTLDashboard'

export const TLDashboard = () => {
  return (
    <ViewTLDashboard/>
  )
}
