import React from 'react'
import { ViewManagerDashboard } from './Partials/ViewManagerDashboard'

export const ManagerDashBoard = () => {
  return (
    <ViewManagerDashboard/>
  )
}
