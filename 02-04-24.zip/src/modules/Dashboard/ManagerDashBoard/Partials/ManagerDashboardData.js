import { SvgIcons } from "../../../../Images";
import holiday from '../../../../Images/holiday.jpg'

export const employeedata = [
  {
    key: "1",
    rate: "ghjgh",
    icon: SvgIcons.Employee,
    p: "Total Employee",
    backgroundColor:
      "linear-gradient(135deg, rgb(134, 182, 246) 0, rgb(56, 135, 190) 100%)",
    backgroundImage: holiday,
  },
];
