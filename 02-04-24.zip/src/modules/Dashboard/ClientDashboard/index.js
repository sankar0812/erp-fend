import React from 'react'
import { ViewClientDashboard } from './Partials/ViewClientDashboard'

export const ClientDashboard = () => {
  return (
   <ViewClientDashboard/>
  )
}
