import React from 'react'
import { ViewAdminDashboard } from './Partials/ViewAdminDashboard'

export const AdminDashboard = () => {
  return (
    <ViewAdminDashboard/>
  )
}
