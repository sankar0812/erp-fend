import React from 'react'
import { ViewPLDashboard } from './Partials/ViewPLDashboard'

export const PLDashBoard = () => {
  return (
    <ViewPLDashboard/>
  )
}
