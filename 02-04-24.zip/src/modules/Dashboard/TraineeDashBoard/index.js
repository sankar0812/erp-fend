import React from 'react'
import { TraineeDashboard } from './Partials/TraineeDashboard'

export const TraineeDashboardDetails = () => {
  return (
    <TraineeDashboard/>
  )
}
