import React from 'react'
import { AccountantDashCard } from './Partials/AccountantDashCard'

const AccountantDashboard = () => {
  return (
    <div><AccountantDashCard/></div>
  )
}

export default AccountantDashboard