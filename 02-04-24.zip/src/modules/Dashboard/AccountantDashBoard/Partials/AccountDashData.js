import { SvgIcons } from "../../../../Images";

export const accountsdata = [
    {
      key: "1",
      rate: "ghjgh",
      icon: SvgIcons.Employee,
      p: "Total Employee",
      backgroundColor:
        "linear-gradient(135deg, rgb(35, 189, 184) 0, rgb(101, 169, 134) 100%)",
    },
    {
      key: "2",
      rate: "xcvbcvb",
      icon: SvgIcons.Present,
      p: "Current Present",
      backgroundColor: "linear-gradient(135deg,#289cf5,#4f8bb7)",
    },
  ];