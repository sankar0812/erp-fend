import React from 'react'
import { ViewClientRequiremets } from './Partials/ViewClientRequirements'

const ClientRequirement = () => {
  return (
    <div><ViewClientRequiremets/></div>
  )
}

export default ClientRequirement