import React from 'react'
import { CustomPageTitle } from '../../../components/CustomPageTitle'
import { AddReceipt } from './Partials/Addreceipts'

const ClientReceipts = () => {
  return (
    <div>
       <AddReceipt />
    </div>
  )
}

export default ClientReceipts