import React, { Fragment } from 'react'
import ViewReceiptsTable from './Partials/viewReceiptsTable'

const ViewReceipts = () => {
    return (
        <Fragment>
            <ViewReceiptsTable />

        </Fragment>
    )
}

export default ViewReceipts