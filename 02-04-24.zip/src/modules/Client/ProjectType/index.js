import React from 'react'
import ViewProjectType from './Partials/ViewProjecttype'

const ProjectType = () => {
    return (
        <div>
            <ViewProjectType />
        </div>
    )
}

export default ProjectType