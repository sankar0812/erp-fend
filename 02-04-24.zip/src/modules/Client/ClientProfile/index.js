import React from 'react'
import { ViewClientProfile } from './Partials/ViewClientProfile'


export const ClientProfile = () => {
  return (
    <div><ViewClientProfile/></div>
  )
}

