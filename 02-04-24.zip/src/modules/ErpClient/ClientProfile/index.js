import React from 'react'
import { ErpClientProfile } from './Partials/ViewClientProfile'

export const ErpClientProfileMain = () => {
    return (
        <div><ErpClientProfile /></div>
    )
}
