import React from 'react'
import { ViewClientInvoice } from './Partials/ViewClientInvoice'

export const ErpClientInvoiceMain = () => {
    return (
        <div><ViewClientInvoice /></div>
    )
}
