import React from 'react'
import { ViewClientQuotation } from './Partials/ViewClientQuotation'

export const ErpClientQuotationMain = () => {
  return (
    <div><ViewClientQuotation/></div>
  )
}
